package com.mycompany.testBase;

//import com.epam.*;
import com.epam.reportportal.testng.ReportPortalTestNGListener;

import org.testng.annotations.Listeners;

@Listeners({ReportPortalTestNGListener.class})
public class BaseTest {
    // some base steps for all tests
}