package stepDefinition;

import java.util.concurrent.TimeUnit;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import com.codoid.products.exception.FilloException;
import com.codoid.products.fillo.Connection;
import com.codoid.products.fillo.Fillo;
import com.codoid.products.fillo.Recordset;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class stepDefinition {
	
	//declarations
	public static WebDriver driver = null;
	public static Recordset rs = null;
	public static Connection connection = null;
	public static Fillo fillo = null;
	private static boolean flag = false;
	
	@Before()// before annotation implemented
	public Object setup() throws FilloException{
		
		//creating fillo object
		Fillo fillo =new Fillo();
		
		//connecting to excel file
		connection = fillo.getConnection("./excel\\data1.xlsx");
		
		//selecting data in excel file
		String strQuery = "select * from adactin";
		rs = connection.executeQuery(strQuery);
		
		//reading first row on excel file
		rs.moveFirst();
		
		return rs;
		
	}//end of before
	
	@Before("@Login")//before annotation for login
	@Given("^user logs into website$")
	public void user_logs_into_website() throws Throwable {
	    
		if(flag==false) {
	        flag=true;
		}
	}
	
	@Given("^I am already on login page$")
	public void i_am_already_on_login_page() throws Throwable {
	    
		//selecting browser between chrome and firefox
		if((rs.getField("Browser")).equalsIgnoreCase("chrome")) {
			String projectPath = System.getProperty("user.dir");
			System.setProperty("webdriver.chrome.driver", projectPath+"/driver/chromedriver.exe");
			driver = new ChromeDriver();
			
		}//end if
		
		else if((rs.getField("Browser")).equalsIgnoreCase("firefox")) {
			String projectPath = System.getProperty("user.dir");
			System.setProperty("webdriver.gecko.driver", projectPath+"/driver/geckodriver.exe");
			driver = new FirefoxDriver();
			
		}//end if
		
		
		//maximising browser to full screen
		driver.manage().window().fullscreen();
		driver.get(rs.getField("Url"));
		
				
	}
	
	@Given("^insert username and password$")
	public void insert_username_and_password() throws Throwable {
	    //getting user input 
		System.out.println("input");
		driver.findElement(By.xpath("//input[@name='username']")).clear();
		driver.findElement(By.xpath("//input[@name='username']")).sendKeys(rs.getField("Username"));
		driver.findElement(By.xpath("//input[@name='password']")).clear();
		driver.findElement(By.xpath("//input[@name='password']")).sendKeys(rs.getField("Password"));
		//Thread.sleep(5000);
		
	}

	@When("^I click on login button$")
	public void i_click_on_login_button() throws Throwable {
	    // click button for login
		driver.findElement(By.xpath("//input[@name='login']")).click();
		System.out.println("click");
	}

	@Then("^I should be logged in$")
	public void i_should_be_logged_in() throws Throwable {
	    // successful login attempt
		System.out.println("logged in");
	}
	
	
	//searching hotel

	@Given("^I am on a search panel$")
	public void i_am_on_a_search_panel() throws Throwable {
	    // begin search
	   System.out.println("search");
	}
	
	@When("^I insert location$")
	public void i_insert_location() throws Throwable {
	    // selecting location
	  
		System.out.println("location"+rs.getField("location")); 
	    Select dropdown = new Select(driver.findElement(By.xpath("//select[@name='location']")));
		dropdown.selectByVisibleText(rs.getField("location"));
	}

	@When("^I insert Hotel$")
	public void i_insert_Hotel() throws Throwable {
	    // selecting hotel 
		System.out.println("hotel");
	    Select dropdown1 = new Select(driver.findElement(By.xpath("//select[@name='hotels']")));
		dropdown1.selectByVisibleText(rs.getField("Hotels"));
	}

	@When("^I insert Room type$")
	public void i_insert_Room_type() throws Throwable {
	    // selecting room type
		System.out.println("room type");
		Select dropdown2 = new Select(driver.findElement(By.xpath("//select[@name='room_type']")));
		dropdown2.selectByVisibleText(rs.getField("RoomType"));
	}

	@When("^I insert Number of rooms$")
	public void i_insert_Number_of_rooms() throws Throwable {
	    // input number of rooms
		System.out.println("number of rooms");
		Select dropdown3 = new Select(driver.findElement(By.xpath("//select[@name='room_nos']")));
		dropdown3.selectByVisibleText(rs.getField("NoOfRooms")); 
	}

	@When("^set Check in and out date$")
	public void set_Check_in_and_out_date() throws Throwable {
	    // setting check in and out date
		System.out.println("check");
		
	    driver.findElement(By.xpath("//input[@name='datepick_in']")).clear();
		driver.findElement(By.xpath("//input[@name='datepick_in']")).sendKeys(rs.getField("CheckInDate"));
		
		driver.findElement(By.xpath("//input[@name='datepick_out']")).clear();
		driver.findElement(By.xpath("//input[@name='datepick_out']")).sendKeys(rs.getField("CheckOutDate"));
	}

	@When("^select adults per room$")
	public void select_adults_per_room() throws Throwable {
	    //selecting adults per room
		System.out.println("adults");
		
		Select dropdown4 = new Select(driver.findElement(By.xpath("//select[@name='adult_room']")));
		dropdown4.selectByVisibleText(rs.getField("AdultsPerRoom"));
	}

	@When("^select children per room$")
	public void select_children_per_room() throws Throwable {
	    //select children per room
		System.out.println("children");
		Select dropdown5 = new Select(driver.findElement(By.xpath("//select[@name='child_room']")));
		dropdown5.selectByVisibleText(rs.getField("ChildrenPerRoom"));
	
	}

	@When("^i click on search button$")
	public void i_click_on_search_button() throws Throwable {
	    //clicking on search button
		System.out.println("click");
	    
		driver.findElement(By.xpath("//input[@id='Submit']")).click();
	}

	@Then("^display see results found$")
	public void display_see_results_found() throws Throwable {
	    //displaying results found after searching
	    System.out.println("results");
	}
	
	
	//selecting hotel of your choice
	@Given("^i should be at select page$")
	public void i_should_be_at_select_page() throws Throwable {
	    // select page
	   System.out.println("select page");
	}

	@When("^i click on select$")
	public void i_click_on_select() throws Throwable {
	    // 
		driver.findElement(By.xpath("//input[@name='radiobutton_0']")).click();
		
		driver.findElement(By.xpath("//input[@name='continue']")).click(); 
	}

	@Then("^i should be redirected to another page$")
	public void i_should_be_redirected_to_another_page() throws Throwable {
	    // redirected to another page
		System.out.println("redirected");
	    
	}
	
	//banking details
	
	@Given("^i am at banking details screen$")
	public void i_am_at_banking_details_screen() throws Throwable {
	    // bank details screen reached
	   System.out.println("banking details screen");
	}

	@When("^i insert first name$")
	public void i_insert_first_name() throws Throwable {
	    // input first name
		driver.findElement(By.xpath("//input[@name='first_name']")).clear();
		driver.findElement(By.xpath("//input[@name='first_name']")).sendKeys(rs.getField("FirstName"));
	}

	@When("^insert last name$")
	public void insert_last_name() throws Throwable {
	    // input last name
		
		driver.findElement(By.xpath("//input[@name='last_name']")).clear();
		driver.findElement(By.xpath("//input[@name='last_name']")).sendKeys(rs.getField("LastName"));
	}

	@When("^insert billing address$")
	public void insert_billing_address() throws Throwable {
	    // input billing address
		
		driver.findElement(By.xpath("//textarea[@name='address']")).clear();
		driver.findElement(By.xpath("//textarea[@name='address']")).sendKeys(rs.getField("Address"));
	}

	@When("^insert credit card number$")
	public void insert_credit_card_number() throws Throwable {
	    // inputting credit card number
		
		driver.findElement(By.xpath("//input[@name='cc_num']")).clear();
		driver.findElement(By.xpath("//input[@name='cc_num']")).sendKeys(rs.getField("CreditNo"));
	}

	@When("^insert credit card type$")
	public void insert_credit_card_type() throws Throwable {
	    // input credit card type
		Select dropdown6 = new Select(driver.findElement(By.xpath("//select[@name='cc_type']")));
		dropdown6.selectByVisibleText(rs.getField("CreditType"));
	}

	@When("^insert expiry date in months and years$")
	public void insert_expiry_date_in_months_and_years() throws Throwable {
	    // input expiry date in and year of card
		Select dropdown7 = new Select(driver.findElement(By.xpath("//select[@name='cc_exp_month']")));
		dropdown7.selectByVisibleText(rs.getField("Month"));
		
		Select dropdown8 = new Select(driver.findElement(By.xpath("//select[@name='cc_exp_year']")));
		dropdown8.selectByVisibleText(rs.getField("Year"));
	}

	@When("^insert CVV number$")
	public void insert_CVV_number() throws Throwable {
	    // input valid CVV number
		
		driver.findElement(By.xpath("//input[@name='cc_cvv']")).clear();
		driver.findElement(By.xpath("//input[@name='cc_cvv']")).sendKeys(rs.getField("CVV"));
		
	}

	@Then("^click on book now\\.$")
	public void click_on_book_now() throws Throwable {
	    // book now button
		
		driver.findElement(By.xpath("//input[@name='book_now']")).click();
	}

	@Then("^redirect to next page$")
	public void redirect_to_next_page() throws Throwable {
	    // redirect to next page reached
	   System.out.println("redirect");
	}
	
	//my booking itinerary
	@Given("^i am on booking iternary$")
	public void i_am_on_booking_iternary() throws Throwable {
	    
	   //clicking my itinerary button
	   WebDriverWait wait = new WebDriverWait(driver,1000);
		
		WebElement button = wait.until(ExpectedConditions.visibilityOfElementLocated(
				By.id("my_itinerary")));
		button.click();
	}

	@When("^i select bookings$")
	public void i_select_bookings() throws Throwable {
	    // select bookings
		driver.findElement(By.xpath("//input[@name='check_all']")).click();
	}

	@When("^click cancel$")
	public void click_cancel() throws Throwable {
	    //cancel button
	    driver.findElement(By.xpath("//input[@name='cancelall']")).click();
	    driver.switchTo().alert().accept();
	}

	@Then("^Booking should be deleted\\.$")
	public void booking_should_be_deleted() throws Throwable {
	    // delete successful
	    System.out.println("deleted booking");
	}

	@Given("^i am already on the log out page$")
	public void i_am_already_on_the_log_out_page() throws Throwable {
	    // log out page reached
	   System.out.println("logout page reached");
	}
	
	//@After("@Logout")
	@When("^i click on logout button$")
	public void i_click_on_logout_button() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		((JavascriptExecutor)driver).executeScript("scroll(0,1800)");
		driver.manage().timeouts().implicitlyWait(1000, TimeUnit.SECONDS);
		
		WebDriverWait wait = new WebDriverWait(driver,1000);
		
		WebElement button = wait.until(ExpectedConditions.visibilityOfElementLocated(
				By.id("logout")));
		button.click();
		
		
	}
	//already logged out
	@Then("^i should be logged out$")
	public void i_should_be_logged_out() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    System.out.println("logged out");
	    driver.manage().timeouts().implicitlyWait(1000, TimeUnit.SECONDS);
	    
	    driver.close();
	   
	    
	}
	
	
}
